<?php

$query = rtrim($_SERVER['REQUEST_URI'], '/');
echo $query;

require "../vendor/core/Router.php";
require "../vendor/libs/functions.php";

Router::add("", ["controller" => "main", "action" => "index"]);

Router::add("/news/index", ["controller" => "news", "action" => "index"]);
Router::add("/news/view", ["controller" => "news", "action" => "view"]);
Router::add("/news/add", ["controller" => "news", "action" => "add"]);


debug(Router::getRoutes());

if (Router::matchRoute($query)){
    debug(Router::getRoute());
} else {
    echo "404";
}
