<?php

namespace app\controllers;

class Photo extends App
{

    public function addAction() {
//        echo "Photo->add";
    }

    public function viewAction() {
//        echo "Photo->view";
    }
}