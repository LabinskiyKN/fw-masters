<form method="post">
    <p>
        <input type="text" name="login">
    </p>
    <p>
        <input type="password" name="password">
    </p>
    <p>
        <input type="submit">
    </p>
</form>
<p><?=$login?></p>
<p><?=$pass?></p>