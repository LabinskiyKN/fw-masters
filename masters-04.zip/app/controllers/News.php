<?php

namespace app\controllers;

class News extends App
{

    public function indexAction() {
        echo "Controller <b>News</b> action <b>index</b>";
    }

    public function viewAction() {
        echo "Controller <b>News</b> action <b>view</b>";
    }
}