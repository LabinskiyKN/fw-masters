<?php


namespace app\controllers;


class Main extends App
{

    public function indexAction() {
        echo "Controller <b>Main</b> action <b>index</b>";
    }

}