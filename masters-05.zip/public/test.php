<?php

class Car {

    public $color = "red";
    public $velocity = 100;

    public function timeOfTrip($distance) {
        return $distance / $this->velocity;
    }

}

$car1 = new Car();
$car1->color = "white";
$car1->velocity = 150;

$car2 = new Car();
$car2->velocity = 200;

echo $car1->timeOfTrip(1000);
echo "<br>";
echo $car2->timeOfTrip(1000);