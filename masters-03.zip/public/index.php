<?php

$query = rtrim($_SERVER['QUERY_STRING'], '/');


define('WWW', __DIR__);
define('CORE', dirname(__DIR__) . "/vendor/core");
define('APP', dirname(__DIR__) . "/app");


require "../vendor/core/Router.php";
require "../vendor/libs/functions.php";


Router::add('^$', ["controller" => "main", "action" => "index"]);
Router::add('^(?P<controller>[a-z]+)/?(?P<action>[a-z]+)?$', []);

debug(Router::getRoutes());


Router::dispatch($query);