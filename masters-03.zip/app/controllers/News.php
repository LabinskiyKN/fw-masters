<?php


class News
{

    public function index() {
        echo "Controller <b>News</b> action <b>index</b>";
    }

    public function view() {
        echo "Controller <b>News</b> action <b>view</b>";
    }
}