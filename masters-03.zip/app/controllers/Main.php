<?php


class Main
{

    public function index() {
        echo "Controller <b>Main</b> action <b>index</b>";
    }

}