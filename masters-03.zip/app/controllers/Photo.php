<?php


class Photo
{

    public function add() {
        echo "Photo->add";
    }

    public function view() {
        echo "Photo->view";
    }
}